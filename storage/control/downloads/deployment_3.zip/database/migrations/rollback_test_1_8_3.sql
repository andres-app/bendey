-- Prueba intencional de rollback TiquePOS 1.8.3.
-- No modifica datos. La primera sentencia es inocua y la segunda falla adrede.
SELECT 1;
TIQUEPOS_ROLLBACK_TEST_FAIL_INTENTIONALLY;
